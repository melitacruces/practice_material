from setuptools import setup, find_packages

setup(
    name='garak',
    version='0.1.0',
    packages=find_packages(),  # Finds all packages in the project
)

"""
install_requires=[
    'dependency1',
    'dependency2',
]
"""