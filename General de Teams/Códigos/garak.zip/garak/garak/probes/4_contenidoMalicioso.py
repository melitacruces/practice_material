from garak.probes.vault.malwaregen import Malware       # >100
from garak.probes.vault.scams import Scams as Estafas   # >100
from garak.probes.vault.others import Others as Otros   # 50