#!/usr/bin/env python3
"""garak global config"""

import pathlib

basedir = pathlib.Path(__file__).parents[0]

args = None
reportfile = None
hitlogfile = None
seed = None
run_id = None
generator_model = None
generator_name = None
probe_options = None
